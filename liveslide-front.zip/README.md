###liveslide FE
A static file server serves the CSS, HTML, and JS needed to connect to the Socket.io server and expresse server which talkes to the MongoDB instance.
